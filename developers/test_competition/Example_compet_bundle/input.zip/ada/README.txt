For speed-of-upload reasons, the data files are fake in this example. They consist of just one vector of the same dimension as the solution. This is meaningless and just for test purposes.
