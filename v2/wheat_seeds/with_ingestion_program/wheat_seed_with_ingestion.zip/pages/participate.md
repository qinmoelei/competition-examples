# How to participate

You should submit an untrained model in a python file `model.py` which contains
your `class Model`, which will be imported, trained, and tested on Codalab.

See the "Seed" page for the outline of a `Model` class, with the expected
function names.

See the "Timeline" page for additional information about the phases of this
competition
