# How to participate

You should submit a text file of your prediction on the testing data provided in "public data". It should be formatted
as follows: 

```text
2
0
1
2
1
...
``` 

See the "Timeline" page for additional information about the phases of this
competition
