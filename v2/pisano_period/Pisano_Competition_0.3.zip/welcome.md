# Welcome

This competition is from Jimmy Keith's weekly code challenges at our company
CKC yadda yadda
